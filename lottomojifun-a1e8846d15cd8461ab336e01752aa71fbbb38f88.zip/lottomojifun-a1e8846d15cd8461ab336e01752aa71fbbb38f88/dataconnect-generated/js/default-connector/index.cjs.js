
const connectorConfig = {
  connector: 'default',
  service: 'lottomojifun',
  location: 'us-east4'
};
exports.connectorConfig = connectorConfig;
